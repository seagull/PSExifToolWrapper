﻿#= seagull's exiftool wrapper :: build 21, december 2023 ===================================================================

[CmdletBinding()] param ([Parameter(ValueFromRemainingArguments=$true)] $varFiles) #this needs to be first for some reason
$Host.UI.RawUI.BackgroundColor='Black'
chcp 65001
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
clear

$varScriptDir=split-path -parent $MyInvocation.MyCommand.Definition
$varEpochNow=[int][double]::Parse((Get-Date -UFormat %s))

function pauseExit ($level) {
    if (!$level) {$level=0}
    write-host `r
    write-host "Script aborted."
    cmd /c pause
    exit $level
}

function toSHA1 {
    param ([parameter(mandatory=$true,ValueFromPipeline=$true)]$pipe)
    return [System.BitConverter]::ToString((New-Object System.Security.Cryptography.SHA1CryptoServiceProvider).ComputeHash([System.IO.File]::ReadAllBytes("$pipe"))).Replace("-","")
}

function parseAwkwardFilename ($filename) {
    #i hate that we have to do this
    $filename.toCharArray() | % {
        if ($_ -notmatch '[\x20-\x7f]') {
            return $true
        }
    }
}

function passAwkwardFilename ($filename) {
@"
-CHARSET
FILENAME=UTF8
-CHARSET
UTF8
-API
WindowsWideFile=
$filename
"@ | out-file "$varScriptDir\exiftool.args" -Encoding UTF8 -Force
}

#= introduction ===========================================================================================================

write-host "seagull's EXIFTool Wrapper" -ForegroundColor Cyan
write-host "=======================================" -ForegroundColor White

#= make a desktop shortcut ("install" the script) =========================================================================

if (!(test-path "$env:public\..\$(((Get-WMIObject -class Win32_ComputerSystem).Username | select -first 1).split('\')[1])\Desktop\EXIFTool.lnk")) {
    $varShortcut=(New-Object -comObject WScript.Shell).CreateShortcut("$env:public\..\$(((Get-WMIObject -class Win32_ComputerSystem).Username | select -first 1).split('\')[1])\Desktop\EXIFTool.lnk")
    $varShortcut.TargetPath="powershell.exe"
    $varShortcut.Arguments="-noexit -file `"$($script:MyInvocation.MyCommand.Path)`""
    $varShortcut.Description="Drag-and-drop files and/or folders onto this shortcut to analyse or scrub their metadata using EXIFTool."
    $varShortcut.Save()

    write-host "- A shortcut to this script (called `"EXIFTool`") has been created on the Desktop." -ForegroundColor Cyan
    write-host "  If you later move this script, delete that shortcut and let the script re-create it."
    write-host "  It is recommended to make a dedicated folder for the script to which you have write access."
    write-host "  EXIFTool will be downloaded into this folder and kept up-to-date automatically."
    write-host `r
    write-host "  Launch this Wrapper script by dragging files onto the Desktop shortcut."
    pauseExit
}

#= throw if administrative rights are required ============================================================================

if (((Get-Acl "$varScriptDir").Access | ? {$_.IdentityReference -match $((Get-WMIObject -class Win32_ComputerSystem).Username -replace '\\','\\')}).FileSystemRights.value__ -ne 2032127) {
    if (!($([bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544")))) {
        write-host "! ERROR: You do not have write access to the folder the script has been placed into." -ForegroundColor Red
        write-host "  Please either manually give yourself full access to the script folder or put it"
        write-host "  in a location in $((Resolve-path "$env:public\..").path) where you have write access."
        write-host "  This is required in order for the script to download and update the EXIFTool binary."
        pauseExit 1
    }
}

#= check exiftool status/version and update as necessary ==================================================================

#pull 'dialogue' from sourceforge & use it to test connectivity
$varXTDlg=(New-Object System.Net.WebClient).DownloadString("https://exiftool.sourceforge.net/checksums.txt")

if (!$varXTDlg) {
    write-host "! ERROR: Could not ascertain latest version of EXIFTool." -ForegroundColor Red
    write-host "  Please check your internet connectivity."
    pauseExit 1
}

#now we're good, pull one more file and sort into our version and SHA1 variables
$varXTVer=(New-Object System.Net.WebClient).DownloadString("https://exiftool.sourceforge.net/ver.txt")
$varXTSHA1=($varXTDlg -split 'zip' | select -skip 1).split([environment]::newline)[0] -split ' ' | select -last 1

#formulate version string like the executable does (THANKS)
[version]$varXTVerFinal="$($varXTVer.split('.')[0]).$(($varXTVer.split('.')[1])[0]).$(($varXTVer.split('.')[1])[1]).0"
write-host ": Latest version of EXIFTool: $varXTVerFinal"

#compare to what we have present, if anything
if (test-path "$varScriptDir\exiftool.exe") {
    if ([version]$varXTVerFinal -notmatch [version]$((get-item "$varScriptDir\exiftool.exe").VersionInfo.ProductVersion)) {
        $varDownload=$true
    }
} else {
    $varDownload=$true
}

if ($varDownload) {
    write-host "! EXIFTool is absent or outdated. Downloading latest version." -ForegroundColor Yellow
    #download
    (new-object System.Net.WebClient).DownloadFile("https://exiftool.org/exiftool-$varXTVer.zip","$varScriptDir\XTLatest.zip")
    #verify
    if ($("$varScriptDir\XTLatest.zip" | toSHA1) -ne $varXTSHA1) {
        write-host "! ERROR: Hash mismatch when downloading EXIFTool." -ForegroundColor Red
        write-host "  Please check manually. Something may be afoot."
        pauseExit 1
    }

    #extract
    remove-item "$varScriptDir\exiftool.exe" -force -ea 0
    $varShell=new-object -comObject shell.application
    ($varShell.NameSpace("$varScriptDir\XTLatest.zip")).items() | % {$varShell.Namespace($varScriptDir).copyhere($_)}
    if (!(test-path "$varScriptDir\exiftool(-k).exe")) {
        write-host "! ERROR: Could not extract EXIFTool binary." -ForegroundColor Red
        write-host "  Please check manually."
        pauseExit 1
    }
    #cleanup
    rename-item "$varScriptDir\exiftool(-k).exe" "$varScriptDir\exiftool.exe"
    remove-item "$varScriptDir\XTLatest.zip" -force -ea 0
    write-host ": EXIFTool updated to $varXTVer."
} else {
    write-host ": EXIFTool installation is up-to-date."
}
write-host "=======================================" -ForegroundColor White

#= now we know exiftool exists, set the shortcut's icon to the exiftool logo ==============================================

$varShortcut=(New-Object -ComObject ("WScript.Shell")).CreateShortcut("$env:public\..\$(((Get-WMIObject -class Win32_ComputerSystem).Username | select -first 1).split('\')[1])\Desktop\EXIFTool.lnk")
$varShortcut.IconLocation="$varScriptDir\exiftool.exe"
$varShortcut.Save()

#= what are we looking to do here =========================================================================================

$arrFiles=@()
if ($varFiles) {
    $varFiles | % {
        if (Test-Path $_ -PathType Container) {
            Get-ChildItem $_ -Recurse | % {
                if (!(Test-Path $($_.FullName) -PathType Container)) {
                    $arrFiles+=$($_.FullName)
                }
            }
        } else {
            $arrFiles+=$_
        }
    }
} else {
    write-host "! ERROR: No files were found." -ForegroundColor Red
    write-host "  The wrapper works by dragging-and-dropping files and/or folders onto it."
    write-host "  Drag something onto the Desktop shortcut to start using the wrapper."
    pauseExit
}

write-host "- Found " -NoNewline; write-host $arrFiles.count -NoNewline -ForegroundColor Red; write-host " file/s."
write-host "  What do you want to do to the metadata?"
write-host `r
write-host "[Q] " -ForegroundColor DarkGray -NoNewline; write-host "View" -ForegroundColor Red
write-host "[A] " -ForegroundColor DarkGray -NoNewline; write-host "Commit to text file" -ForegroundColor Red
write-host "[Z] " -ForegroundColor DarkGray -NoNewline; write-host "Scrub" -ForegroundColor Red
write-host `r

#= another grand switch ===================================================================================================

[int]$varCounter=0
switch (read-host "Decision") {
    q {
        $arrFiles | % {
            $varCounter++
            write-host ": File " -NoNewline -foregroundcolor Cyan; write-host $varCounter -NoNewline -ForegroundColor Red; write-host " of " -NoNewline -foregroundcolor Cyan; write-host $($arrFiles.count) -ForegroundColor Red
            write-host `r

            #awkward filename
            if (parseAwkwardFilename "$_") {
                passAwkwardFilename "$_"
                start-process "$varScriptDir\exiftool.exe" -ArgumentList "-@ `"$varScriptDir\exiftool.args`" -k" -NoNewWindow -Wait
            } else {
                start-process "$varScriptDir\exiftool.exe" -ArgumentList "`"$_`" -k" -NoNewWindow -Wait
            }
        }
    }

    a {
        #get report filename
        $varReport=read-host "Full path of text file to save data in"
        $varReport=$varReport -replace '"'

        set-content $varReport "EXIFTool Wrapper Output :: $(get-date)`n==================================================="
        $arrFiles | % {
            $varCounter++
            stop-process -name exiftool -Force -ea 0
            write-host ": File " -NoNewline -foregroundcolor Cyan; write-host $varCounter -NoNewline -ForegroundColor Red; write-host " of " -NoNewline -foregroundcolor Cyan; write-host $($arrFiles.count) -ForegroundColor Red

            #awkward filename
            if (parseAwkwardFilename "$_") {
                passAwkwardFilename "$_"
                start-process "$varScriptDir\exiftool.exe" -ArgumentList "-@ `"$varScriptDir\exiftool.args`"" -RedirectStandardOutput output$varEpochNow.txt -NoNewWindow -Wait
            } else {
                start-process "$varScriptDir\exiftool.exe" -ArgumentList "`"$_`"" -RedirectStandardOutput output$varEpochNow.txt -NoNewWindow -Wait
            }

            set-content $varReport "$(get-content $varReport -Raw)`r- - - - - - - - - - - -`r$(get-content output$varEpochNow.txt -raw)" -Encoding UTF8
            remove-item output$varEpochNow.txt -force
            start-sleep -seconds 1
        }
        write-host "===================================================" | out-file $varReport -Append
        write-host ": Report saved to $varReport."
    }

    z {
        $varConfirmation=read-host ": Original files will be scrubbed permanently without saving backups. Type OK to confirm"
        if ($varConfirmation -match 'ok') {

            #awkward filename cop-out
            write-host ": Analysing filenames for compatibility with scrub operation..."
            $arrFiles | % {
                if (parseAwkwardFilename "$_") {
                    write-host "! ERROR: File `"$_`" has a filename too awkward for EXIFTool to manage." -ForegroundColor Red
                    write-host "  Please rename this file (and any other files in the set) to contain standard Latin-A characters only."
                    write-host "  The wrapper does its best to work around EXIFTool's filename idiosyncracies but this one was too complicated."
                    pauseExit
                }
            }
            write-host ": All files OK. Proceeding."

            #demonstrate output pre-scrub
            write-host `r
            write-host ": Example of file pre-scrubbing operation:"
            $arrFiles | select -first 1 | % {
                start-process "$varScriptDir\exiftool.exe" -ArgumentList "`"$_`"" -NoNewWindow -Wait
            }
            write-host `r

            #actually scrub them
            $arrFiles | % {
                $varCounter++
                write-host ": File " -NoNewline -foregroundcolor Cyan; write-host $varCounter -NoNewline -ForegroundColor Red; write-host " of " -NoNewline -foregroundcolor Cyan; write-host $($arrFiles.count) -ForegroundColor Red
                start-process "$varScriptDir\exiftool.exe" -ArgumentList "-all= `"$_`" -overwrite_original" -NoNewWindow -wait -RedirectStandardOutput "NUL"
                start-sleep -seconds 1
            }

            #demonstrate output post-scrub
            write-host `r
            write-host ": Example of same file post-scrubbing operation:"
            $arrFiles | select -first 1 | % {
                start-process "$varScriptDir\exiftool.exe" -ArgumentList "`"$_`"" -NoNewWindow -Wait
            }
        } else {
            write-host "! ERROR: Confirmation of terms of scrubbing operation not provided." -ForegroundColor Red
            write-host "  Make your backups if you need them, then come back when you're certain."
            pauseExit
        }
    }

    default {
        write-host "! ERROR: No valid option selected." -ForegroundColor Red
        write-host "  Valid options were Q, A or Z."
        write-host "  Restart the script and press the buttons harder."
        pauseExit 1
    }
}

#= closeout ===============================================================================================================

if (test-path "$varScriptDir\exiftool.args") {remove-item "$varScriptDir\exiftool.args" -force}
write-host "=======================================" -ForegroundColor White
write-host "EXIFTool Wrapper by seagull" -ForegroundColor Red
write-host "www.twitter.com/seagull" -ForegroundColor DarkGray
pauseExit